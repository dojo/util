# Data for testing expected behavior of CLDR operations
#  Copyright © 1991-2020 Unicode, Inc.
#  For terms of use, see http://www.unicode.org/copyright.html
#  Unicode and the Unicode Logo are registered trademarks of Unicode, Inc. in the U.S. and other countries.
#  CLDR data files are interpreted according to the LDML specification (http://unicode.org/reports/tr35/)
# The format may vary between folders or files.